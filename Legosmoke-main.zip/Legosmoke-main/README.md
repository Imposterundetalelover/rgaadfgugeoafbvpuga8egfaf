# [!] Warning

if you leak any source, you will be sued and your ip will be leaked -- all a joke
#
but dont skid/leak its not the right thing to do the creater of the scripts will be quite pissed (me)

# [?] Socials

discord: https://discord.gg/9ujRwzbpCU
#
youtube: https://www.youtube.com/channel/UC6n_1Pyw_QYIPx2e8-YBqyQ
